package ticTacToe;

public enum CellType {
    X, O, E, I, H
}

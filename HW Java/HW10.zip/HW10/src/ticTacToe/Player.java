package ticTacToe;

public interface Player {
    Move move(Position position, CellType cell);
}

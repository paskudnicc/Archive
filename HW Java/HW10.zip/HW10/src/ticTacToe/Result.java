package ticTacToe;

public enum Result {
    WIN, BROKEN, DRAW, UNKNOWN
}
